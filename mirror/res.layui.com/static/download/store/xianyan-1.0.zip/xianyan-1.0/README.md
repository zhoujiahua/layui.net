
> 闲言轻博客模版，基于 layui 搭建而成的响应式轻量极简的“轻博客模板”

> 官网：http://www.layui.com/template/xianyan/

该模板由 [贤心](https://github.com/sentsin) 设计， 由 layui 团队新人 [xzw1999](https://github.com/xzw1999) 完成前端编码。
